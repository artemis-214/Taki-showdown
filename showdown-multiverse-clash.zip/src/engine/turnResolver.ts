import { RuntimeFighterState, MoveData } from '../data/types';
import { calculateDamage } from './damageCalculator';
import { BattleEvent } from './battleEvents';

export type TurnAction =
  | { type: 'move'; moveId: string }
  | { type: 'switch'; targetFighterIndex: number };

export interface BattleSideState {
  team: [RuntimeFighterState, RuntimeFighterState, RuntimeFighterState];
  activeIdx: number;
}

export interface BattleAuthoritativeState {
  turnNumber: number;
  player: BattleSideState;
  opponent: BattleSideState;
  isOver: boolean;
  winner: 'player' | 'opponent' | null;
  history: BattleEvent[];
  stats: { damageDealt: number; criticalHits: number; fightersLost: number; };
}

export function resolveTurn(
  state: BattleAuthoritativeState,
  playerAction: TurnAction,
  opponentAction: TurnAction,
  moveDatabase: Map<string, MoveData>,
  rng = Math.random
): { nextState: BattleAuthoritativeState; events: BattleEvent[] } {
  if (state.isOver) return { nextState: state, events: [] };

  const events: BattleEvent[] = [];
  const nextPlayer = structuredClone(state.player);
  const nextOpponent = structuredClone(state.opponent);
  const nextStats = { ...state.stats };

  events.push({ type: 'turn_started', turnNumber: state.turnNumber });

  if (playerAction.type === 'switch') {
    const targetIdx = playerAction.targetFighterIndex;
    if (targetIdx !== nextPlayer.activeIdx && !nextPlayer.team[targetIdx]?.isFainted) {
      nextPlayer.activeIdx = targetIdx;
      events.push({ type: 'fighter_switched', side: 'player', fighterId: nextPlayer.team[targetIdx]!.id, fighterName: nextPlayer.team[targetIdx]!.name });
    }
  }

  if (opponentAction.type === 'switch') {
    const targetIdx = opponentAction.targetFighterIndex;
    if (targetIdx !== nextOpponent.activeIdx && !nextOpponent.team[targetIdx]?.isFainted) {
      nextOpponent.activeIdx = targetIdx;
      events.push({ type: 'fighter_switched', side: 'opponent', fighterId: nextOpponent.team[targetIdx]!.id, fighterName: nextOpponent.team[targetIdx]!.name });
    }
  }

  const getEffectiveSpeed = (f: RuntimeFighterState) => (f.stats.speed * Math.pow(1.5, f.statStages.speed)) * (f.status === 'paralyze' ? 0.5 : 1);

  const queuedActions: Array<{ side: 'player' | 'opponent'; action: TurnAction; speed: number; priority: number; }> = [];

  if (playerAction.type === 'move') {
    const m = moveDatabase.get(playerAction.moveId);
    queuedActions.push({ side: 'player', action: playerAction, speed: getEffectiveSpeed(nextPlayer.team[nextPlayer.activeIdx]!), priority: m ? m.priority : 0 });
  }
  if (opponentAction.type === 'move') {
    const m = moveDatabase.get(opponentAction.moveId);
    queuedActions.push({ side: 'opponent', action: opponentAction, speed: getEffectiveSpeed(nextOpponent.team[nextOpponent.activeIdx]!), priority: m ? m.priority : 0 });
  }

  queuedActions.sort((a, b) => (a.priority !== b.priority ? b.priority - a.priority : a.speed !== b.speed ? b.speed - a.speed : rng() > 0.5 ? 1 : -1));

  for (const item of queuedActions) {
    const isPlayer = item.side === 'player';
    const attacker = isPlayer ? nextPlayer.team[nextPlayer.activeIdx]! : nextOpponent.team[nextOpponent.activeIdx]!;
    const defender = isPlayer ? nextOpponent.team[nextOpponent.activeIdx]! : nextPlayer.team[nextPlayer.activeIdx]!;

    if (attacker.isFainted) continue;

    if (item.action.type === 'move') {
      const move = moveDatabase.get(item.action.moveId);
      if (!move) continue;

      if (attacker.status === 'stun') {
        events.push({ type: 'action_skipped_status', side: item.side, fighterName: attacker.name, reason: 'stun' });
        attacker.status = null;
        continue;
      }
      if (attacker.status === 'paralyze' && rng() < 0.25) {
        events.push({ type: 'action_skipped_status', side: item.side, fighterName: attacker.name, reason: 'paralyze' });
        continue;
      }

      attacker.currentPp[move.id] = Math.max(0, (attacker.currentPp[move.id] ?? move.maxPp) - 1);
      events.push({ type: 'move_used', side: item.side, fighterName: attacker.name, moveName: move.name, moveType: move.type });

      if (rng() * 100 > move.accuracy) {
        events.push({ type: 'move_missed', userSide: item.side, moveName: move.name });
        continue;
      }

      if (move.effect.kind === 'damage' || move.effect.kind === 'drain') {
        const damageRes = calculateDamage(attacker, defender, move, rng());
        if (defender.currentShield > 0) defender.currentShield = Math.max(0, defender.currentShield - damageRes.absorbedByShield);
        defender.currentHp = Math.max(0, defender.currentHp - damageRes.actualHpLost);

        if (isPlayer) {
          nextStats.damageDealt += damageRes.damage;
          if (damageRes.isCritical) nextStats.criticalHits++;
        }

        events.push({
          type: 'damage_dealt', targetSide: isPlayer ? 'opponent' : 'player', targetName: defender.name,
          damage: damageRes.damage, absorbedByShield: damageRes.absorbedByShield, remainingHp: defender.currentHp,
          isCritical: damageRes.isCritical, typeMultiplier: damageRes.typeMultiplier
        });

        if (move.effect.kind === 'drain') {
          const healValue = Math.floor(damageRes.damage * 0.5);
          attacker.currentHp = Math.min(attacker.stats.maxHp, attacker.currentHp + healValue);
          events.push({ type: 'healed', side: item.side, fighterName: attacker.name, amount: healValue, newHp: attacker.currentHp });
        }
      }

      if (move.effect.kind === 'heal' && move.effect.healAmount) {
        attacker.currentHp = Math.min(attacker.stats.maxHp, attacker.currentHp + move.effect.healAmount);
        events.push({ type: 'healed', side: item.side, fighterName: attacker.name, amount: move.effect.healAmount, newHp: attacker.currentHp });
      }

      if (move.effect.kind === 'shield' && move.effect.shieldAmount) {
        attacker.currentShield += move.effect.shieldAmount;
        events.push({ type: 'shield_applied', side: item.side, fighterName: attacker.name, amount: move.effect.shieldAmount, totalShield: attacker.currentShield });
      }

      if (move.effect.status && rng() * 100 <= move.effect.statusChance && !defender.status) {
        defender.status = move.effect.status;
        events.push({ type: 'status_applied', side: isPlayer ? 'opponent' : 'player', fighterName: defender.name, status: move.effect.status });
      }

      if (defender.currentHp <= 0) {
        defender.isFainted = true;
        events.push({ type: 'fighter_fainted', side: isPlayer ? 'opponent' : 'player', fighterName: defender.name });
        if (!isPlayer) nextStats.fightersLost++;
        break;
      }
    }
  }

  const checkBurn = (f: RuntimeFighterState, side: 'player' | 'opponent') => {
    if (!f.isFainted && f.status === 'burn') {
      const burnDmg = Math.max(1, Math.floor(f.stats.maxHp * 0.08));
      f.currentHp = Math.max(0, f.currentHp - burnDmg);
      events.push({ type: 'status_damage', side, fighterName: f.name, status: 'burn', damage: burnDmg });
      if (f.currentHp <= 0) {
        f.isFainted = true;
        events.push({ type: 'fighter_fainted', side, fighterName: f.name });
        if (side === 'player') nextStats.fightersLost++;
      }
    }
  };

  checkBurn(nextPlayer.team[nextPlayer.activeIdx]!, 'player');
  checkBurn(nextOpponent.team[nextOpponent.activeIdx]!, 'opponent');

  const replaceIfFainted = (sideState: BattleSideState, side: 'player' | 'opponent') => {
    const active = sideState.team[sideState.activeIdx]!;
    if (active.isFainted) {
      const nextHealthyIdx = sideState.team.findIndex((f) => !f.isFainted);
      if (nextHealthyIdx !== -1) {
        sideState.activeIdx = nextHealthyIdx;
        events.push({ type: 'replacement_sent_out', side, fighterId: sideState.team[nextHealthyIdx]!.id, fighterName: sideState.team[nextHealthyIdx]!.name });
      }
    }
  };

  replaceIfFainted(nextPlayer, 'player');
  replaceIfFainted(nextOpponent, 'opponent');

  const playerDefeated = nextPlayer.team.every((f) => f.isFainted);
  const opponentDefeated = nextOpponent.team.every((f) => f.isFainted);

  let isOver = false;
  let winner: 'player' | 'opponent' | null = null;
  if (playerDefeated || opponentDefeated) {
    isOver = true;
    winner = opponentDefeated ? 'player' : 'opponent';
    events.push({ type: 'battle_concluded', winner, totalTurns: state.turnNumber });
  }

  return {
    nextState: {
      turnNumber: state.turnNumber + 1,
      player: nextPlayer,
      opponent: nextOpponent,
      isOver,
      winner,
      history: [...state.history, ...events],
      stats: nextStats,
    },
    events,
  };
}
