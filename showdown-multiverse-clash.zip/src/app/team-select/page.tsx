'use client';
import React, { useState } from 'react';
import Link from 'next/link';
import { ArcadeCabinet } from '../../components/battle/ArcadeCabinet';
import fightersRaw from '../../data/defaultRoster.json';
import { Storage } from '../../lib/storage';
import { SoundManager } from '../../components/audio/SoundManager';
import { FighterData } from '../../data/types';

export default function TeamSelectPage() {
  const [campaign, setCampaign] = useState(Storage.loadCampaign);
  const [selectedIds, setSelectedIds] = useState<string[]>(campaign.selectedTeam);

  const toggleSelect = (id: string) => {
    SoundManager.playBlip();
    if (selectedIds.includes(id)) setSelectedIds(selectedIds.filter((x) => x !== id));
    else if (selectedIds.length < 3) setSelectedIds([...selectedIds, id]);
  };

  const handleSaveTeam = () => {
    if (selectedIds.length !== 3) return;
    SoundManager.playConfirm();
    const updated = { ...campaign, selectedTeam: selectedIds as [string, string, string] };
    setCampaign(updated);
    Storage.saveCampaign(updated);
    window.location.href = '/battle';
  };

  return (
    <main className="min-h-screen bg-obsidian text-arcade-text p-4 flex justify-center">
      <ArcadeCabinet>
        <div className="flex justify-between items-center mb-6 border-b-2 border-black pb-2">
          <Link href="/" className="font-arcade text-xs text-arcade-steel hover:text-arcade-cyan">&lt; HUB</Link>
          <span className="font-arcade text-xs text-arcade-cyan">DRAFT PARTY ({selectedIds.length}/3)</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {(fightersRaw as unknown as FighterData[]).map((f) => (
            <div key={f.id} onClick={() => toggleSelect(f.id)} className={`p-4 border-4 border-black cursor-pointer shadow-pixel ${selectedIds.includes(f.id) ? 'bg-panel-raised border-arcade-cyan' : 'bg-panel-dark hover:bg-panel-raised'}`}>
              <div className="flex justify-between items-center mb-2"><span className="font-arcade text-xs text-arcade-cyan">{f.name}</span><span className="text-[10px] text-arcade-steel font-arcade">{f.types.join('/')}</span></div>
              <div className="font-retro text-lg text-arcade-steel mb-2">{f.title}</div>
            </div>
          ))}
        </div>
        <div className="flex justify-end">
          <button disabled={selectedIds.length !== 3} onClick={handleSaveTeam} className="px-6 py-3 border-4 border-black bg-arcade-magenta text-black font-arcade text-xs shadow-pixel disabled:opacity-40">LOCK IN TEAM</button>
        </div>
      </ArcadeCabinet>
    </main>
  );
}
